# MARZZELLI V5.3 — Corrección de Contacto

Esta actualización elimina los asteriscos que aparecían en líneas separadas en los campos **Nombre**, **¿Qué producto te interesa?** y **Mensaje**.

No modifica JavaScript, CSS, catálogo, fotografías ni otros HTML. La validación de los tres campos obligatorios sigue activa mediante `required` y la función JavaScript existente. Correo continúa siendo opcional.

## Instalar
1. Conserva copia de seguridad del proyecto actual.
2. Copia solamente `contacto.html` a la carpeta raíz del proyecto en VS Code y acepta reemplazarlo.
3. Abre la página `contacto.html` con Live Server, revisa que no aparezcan los asteriscos y prueba el botón **Preparar mensaje** sin completar datos (debe solicitar los campos necesarios).
4. Sube **solo `contacto.html`** a GitHub en la misma carpeta que `index.html`, confirma los cambios y comprueba Actions.
5. Actualiza la página publicada con Ctrl + F5.

No es necesario volver a subir las fotografías ni regenerar `catalogo-fotos.js`.
